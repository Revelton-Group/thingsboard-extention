# Handoff: Hotel IoT Dashboard

## Overview
A dark-themed hotel operations dashboard ("Revelton Studios") for monitoring room IoT sensors — temperature, humidity, CO₂, TVOC, PM2.5/PM10, pressure, lux, noise, windows, water leaks — and controlling thermostats, alert thresholds, and per-room device settings across a property. Includes a top-level KPI strip, a grid of room cards, a full room-detail view with live sensor cards + historical charts, a global control-settings panel, and a historical-data modal. Supports English/Russian language toggle and light/dark theme toggle.

## About the Design Files
The file in this bundle (`Hotel IoT Dashboard.dc.html`) is a **design reference built in HTML** — a high-fidelity interactive prototype demonstrating layout, styling, states, and behavior. It is not production code to copy verbatim. The task is to **recreate this design in your codebase's existing environment** (React, Vue, native, etc.), using your established component patterns, state management, and data layer — or, if no framework is chosen yet, to pick the most appropriate one and implement the design there. Treat all data shown (room names, sensor values, guest names, addresses) as placeholder/mock data to be replaced by real data sources.

## Fidelity
**High-fidelity.** Colors, spacing, typography, and interaction states shown are final-intent. Recreate pixel-close using the values in the Design Tokens section below.

## Screens / Views

### 1. Main Dashboard (Room Grid)
- **Purpose**: Property overview — KPIs at a glance, then a scannable grid of every room's live sensor status. Click a room card to open its detail view.
- **Layout**: Root container `max-width: 2600px`, centered, outer page padding `clamp(14px,1.6vw,26px) clamp(6px,0.6vw,12px) 48px`.
  - **Header** (flex row, space-between, wraps): left = property name "Revelton *Studios*" (italic accent-colored second word) + address line with location icon. Right = date/time + weather, language toggle button, "Control Settings" button, theme toggle button (pill, accent-colored background when active).
  - **KPI strip**: CSS grid, `repeat(auto-fit, minmax(160px,1fr))`, gap `~10-14px`. Each KPI card: 66px min-height, flex row — 36×36px icon tile (rounded 11px) + label/value stack, optional circular progress ring (conic-gradient) on the right for the Occupancy card. KPIs shown: Occupancy (with % ring), Check-ins Today, Check-outs Today, Online/Offline, Battery Alerts, Mews Bridge status.
  - **Room grid**: CSS grid `repeat(auto-fill, minmax(min(100%,260px),1fr))`, gap `~11-16px`, inside a bordered panel container.
    - Each **room card**: relative-positioned, 1.5px border (color reflects alert state), radius 15px, padding `15px 12px 12px`, hover = lift `translateY(-3px)` + shadow.
      - Floating "ROOM N" tab pill centered on the top border edge.
      - Header row: status dot + room name (truncates) + alert count badge (bell icon, red) if alerts exist.
      - 3×3 tile grid (`data-room-tiles`, gap 6px) of small metric tiles, each: icon + uppercase label on one line, value below. Tile padding `7px 3px` (3px left/right — keep tiles compact). Tiles: Temp, Humidity, Air quality, Thermostat setpoint, Window state, Check-in/out status, Water leak, Noise (dB), Booking status. Tile border color reflects state (ok/warn/alert/accent).

### 2. Room Detail (modal, full-screen overlay)
- **Purpose**: Deep dive into one room's live sensors, thermostats, alerts, and historical trends.
- **Layout**: Full-viewport overlay (`position:fixed;inset:0`), fades in. Inner panel is full-bleed (100vw/100vh), flex column: fixed header, scrollable body.
  - **Header**: 44×44px bed icon tile (with small colored status dot badge) + room number/name + guest name + "Connected" live indicator (pulsing dot) + **Check-in/Check-out block** (two label/value pairs, divided by vertical borders from the rest of the header) + amber "checkout passed" pill (icon + text) + close button.
  - **Body sections** (ordered via CSS `order` on a `display:flex;flex-direction:column` container — Sensors & Control Panel renders before Indoor Climate in DOM but visually the two sections are: Sensors & Control Panel first, Indoor Climate below):
    - **Sensors & Control Panel**: grid of device cards (`repeat(auto-fit,minmax(300px,1fr))`) — Air Quality card (temp/humidity/CO₂ big stats row + TVOC/PM2.5/PM10 row + lux/pressure/motion row), 1 Presence sensor card, 1-3 Thermostat cards (Preset stepper with −/value/+ , Status readout, Mode select, Preset select), Noise card, Window card, 2 Water-leak rows.
    - **Indoor Climate** (the historical-data section): header row with section title + **24H/7D/30D range toggle** (segmented control, active = accent bg). Below: a responsive grid (`repeat(auto-fit,minmax(210px,1fr))`) of **vital cards** — Temperature, Humidity, CO₂, Noise, TVOC, PM2.5, PM10, Pressure, Lux, Window (event count), Water Leak (event count). Each card: icon+label+status pill header, big value (30px mono) + unit, an interactive sparkline (or event bar-strip for Window/Leak), and a MIN/AVG/MAX (or duration stats) footer row.
    - Alerts list (recent threshold breaches, per sensor).

### 3. Control Settings (modal)
- **Purpose**: Configure alert thresholds and per-device settings, scoped to all rooms or a targeted subset.
- **Layout**: Centered modal, max-width 940px, ~700px tall, header with title + close, scope selector (All Rooms / Target Specific — opens a searchable room-chip picker), left nav tabs (Air Quality, Thermostats, Acoustic/Noise, Windows, MEWS Bridge, Telegram/notifications), tab content = threshold gauge cards (label, icon, current value ring/gauge, −/+ stepper for the limit), schedule lists (quiet hours, maintenance tests), save button (accent, bottom-right, shows target room count).

### 4. Historical Data (modal) — property-wide, separate from per-room Indoor Climate
- **Purpose**: A dedicated deep-dive view (opened from elsewhere in the app) for one metric set with the same 24H/7D/30D toggle.
- **Layout**: Centered modal, max-width 1180px. Grid (`repeat(auto-fit,minmax(330px,1fr))`) of 4 cards: Temp/Humidity history (dual-line chart + legend), CO₂ analysis (area+line chart), Noise levels (bar chart + LAeq stat), Windows history (open count / avg duration stats + recent-event log rows).

## Interactions & Behavior
- **Room card → Room Detail**: click opens full-screen modal (`fadein` 0.2s ease). Click backdrop or × closes it.
- **Range toggle (24H/7D/30D)**: switches the underlying mock time-series window for all vital cards in that section simultaneously; active pill gets accent background/text, others neutral.
- **Sparkline hover** (Indoor Climate vital cards — the key custom interaction):
  - Hovering anywhere along a card's sparkline tracks the nearest data point (via a full-size transparent capture rect over the SVG, mapping cursor X → nearest sample index).
  - On hover: draws a dashed/opacity vertical guide + an enlarged dot at that point, and shows a floating tooltip positioned above the point containing **both the timestamp and the value** (e.g. "01.07 14:20" / "27.9 °C"). Tooltip clamps horizontally so it never overflows the card.
  - Time labels are generated from the selected range: 24H → time only (HH:mm); 7D and 30D → date + time (DD.MM HH:mm).
  - Leaving the chart clears the hover state (guide/dot/tooltip disappear).
  - **Window / Water Leak cards** use a bar-strip instead of a line: one thin vertical bar per sample, colored on/off (open=amber, leak=red, otherwise neutral); hovering a bar shows the same time+state tooltip. Footer stats for these two cards are event count (big value) + min/avg/max **event duration in minutes** (not degrees/ppm).
  - Degree symbols (°) for all temperature displays (Air Quality card, thermostat Preset/Status, Indoor Climate Temperature card) are rendered as a small superscript flush with the **top** of the digits (not baseline/middle) — position the "°" absolutely at the top-right corner of the number, sized ~40-45% of the number's font-size, with enough gutter before any trailing unit letter (e.g. "C") so it doesn't collide with the raised degree mark.
- **Thermostat stepper**: −/+ buttons adjust setpoint by increments (e.g. 0.5°), clamped to a min/max range; changing the stepper also updates the mode to reflect manual override.
- **Mode/Preset selects**: native `<select>` styled to match the panel (dark bg, custom radius/padding).
- **Control Settings scope**: toggling "Target Specific" reveals a searchable multi-select chip list of rooms; "applies to N of M rooms" summary updates live.
- **Language toggle**: swaps entire UI string set between English and Russian (see Design Tokens/i18n below).
- **Theme toggle**: swaps CSS custom-property values for a light ("Daylight") vs dark ("Midnight") theme; icon/label change accordingly.
- **Alerts**: rows list recent threshold breaches with sensor, limit, message, and relative time.

## State Management
Minimum state needed to reproduce behavior:
- `lang`: 'en' | 'ru' — drives all copy via a dictionary lookup.
- `theme`: 'dark' | 'light' — drives CSS custom property values.
- `rooms[]`: array of room records (id, name, status, sensor readings, thermostats[], window/water/noise state, alerts, booking/check-in-out).
- `selected`: currently open room id (drives Room Detail modal visibility + content).
- `showControl`, `showHistory`: booleans for the two other modals.
- `histRange`: '24h' | '7d' | '30d' — shared by both the per-room Indoor Climate section and the global Historical Data modal.
- `sparkHover`: `{ id: string, idx: number } | null` — which chart/card is hovered and at which sample index; drives the guide line, dot/bar highlight, and tooltip. Keyed by a per-card id (e.g. 'temp', 'hum', 'co2', 'noise', 'tvoc', 'pm25', 'pm10', 'pres', 'lux', 'win', 'leak') so multiple cards' hover states don't collide.
- Control-panel local state: active tab, threshold values per sensor, scope (all vs target list + search query), schedules.
- Thermostat local state: mode, preset, setpoint per thermostat unit (a room can have multiple).

Data needed per historical sample (for charts): a value array per metric plus a parallel array of real timestamps (don't reuse the mock's seeded-random generator — replace with real sensor history from your backend, sampled at a density appropriate to the selected range).

## Design Tokens

### Colors (dark theme — CSS custom properties with fallback hex shown)
- `--bg`: `#0d1219` (page background)
- `--panel`: `#141b25` (card/modal surface)
- `--panel2`: `#1a2230` (nested surface, e.g. tiles, pills)
- `--inner`: `#1e2733` (innermost surface, e.g. stat sub-cards)
- `--border`: `#27313f`
- `--tx`: `#e6ecf3` (primary text)
- `--t2`: `#8b97a8` (secondary text)
- `--t3`: `#5c6675` (tertiary/muted text, labels)
- `--accent`: `#5c7cfa` (primary brand/interactive blue)
- `--accentSoft`: `rgba(92,124,250,.14)` (accent tint background)
- `--ok`: `#34d399` (success/normal), `--okSoft`: `rgba(52,211,153,.13)`
- `--warn`: `#f5b54a` (warning), `--warnSoft`: `rgba(245,181,74,.13)`
- `--alert`: `#f87171` (critical/error), `--alertSoft`: `rgba(248,113,113,.13)`
- `--ringTrack`: `#27313f` (KPI ring track)
- Chart accent colors (not swapped by theme): humidity `#46d39a`, CO₂ `#a594ff`, TVOC `#f5b54a`, PM2.5 `#f2789a`, PM10 `#5cc8f5`, Pressure `#9aa5b1`, Lux `#7cd9c0`.
- A light theme ("Daylight") exists — swap these custom properties to light equivalents; component code doesn't change.

### Typography
- **UI font**: Manrope (weights 500/600/700), system-ui fallback.
- **Data/numeric font**: 'IBM Plex Mono' — used for all metric values, timestamps, room numbers.
- **Icons**: Material Symbols (class `ms`), sized 12-23px inline with text.
- Scale in use: labels/eyebrows 8.5-11px (700 weight, letter-spacing .4-.8px, uppercase), body 11.5-13.5px, big stat values 17-30px, section titles 17-27px.

### Spacing / Radius
- Card radius: 14-20px (large panels), 9-15px (medium cards), 7-11px (tiles/pills/buttons).
- Page gutter: `clamp(14px,1.6vw,26px)` top/bottom, `clamp(6px,0.6vw,12px)` left/right (kept intentionally tight per latest feedback).
- Grid gaps: 6px (room tiles) to 16px (major card grids).
- Room-tile inner padding: `7px 3px` (3px left/right specifically — do not increase).

### Degree-symbol treatment (apply everywhere a temperature is shown)
Number in its normal font size; "°" as an absolutely-positioned span, `top: 0-2px`, `right: -8 to -12px` (scaled to the number's font-size), font-size ~40-45% of the number, color muted (`--t3`). Any trailing unit letter (e.g. "C") needs `margin-left` large enough (roughly the degree's offset + its own width, ~13-16px at 24-30px number sizes, ~13px at 18px number size) so it renders after the raised degree mark, not under/through it.

## Assets
No bitmap image assets — all icons are Material Symbols glyphs (icon font, referenced by ligature name, e.g. `device_thermostat`, `co2`, `water_drop`, `window`, `graphic_eq`). Charts are hand-built inline SVG (polylines/paths), not an image or charting library. Room "photos" are not used; rely on icon + color coding only.

## Files
- `Hotel IoT Dashboard.dc.html` — the full design source (structure + inline logic). All styling is inline (no external stylesheet) by design-tool convention; when recreating, translate the inline styles into your codebase's normal styling approach (CSS modules, Tailwind, styled-components, etc.) rather than keeping everything inline.
